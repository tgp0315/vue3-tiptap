### 多人协同插件

```
@tiptap/extension-collaboration yjs
```