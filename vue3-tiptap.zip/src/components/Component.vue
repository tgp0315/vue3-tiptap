<template>
<node-view-wrapper class="draw">
    <input type="color" v-model="color">
    <input
      type="number"
      min="1"
      max="10"
      v-model="size"
    >
    <button @click="clear">
      clear
    </button>
    <svg viewBox="0 0 500 250" ref="canvas">
      <template v-for="item in node.attrs.lines">
        <path
          v-if="item.id !== id"
          :key="item.id"
          :d="item.path"
          :id="`id-${item.id}`"
          :stroke="item.color"
          :stroke-width="item.size"
        />
      </template>
    </svg>
  </node-view-wrapper>   
</template>
  
<script setup lang='ts'>
import { nodeViewProps, NodeViewWrapper } from '@tiptap/vue-3'
import * as d3 from 'd3'
import { v4 as uuid } from 'uuid'
import { onMounted } from 'vue';
const getRandomElement = (list: Array<any>) => {
  return list[Math.floor(Math.random() * list.length)]
}
defineProps(nodeViewProps)

const color = getRandomElement([
  '#A975FF',
  '#FB5151',
  '#FD9170',
  '#FFCB6B',
  '#68CEF8',
  '#80CBC4',
  '#9DEF8F',
])
const size = Math.ceil(Math.random() * Math.floor(10))
const svg = null
const path = null
let points = []
const drawing = false
const id = uuid()
const onStartDrawing = (event) => {
      drawing = true
      points = []
      path = svg
        .append('path')
        .data([points])
        .attr('id', `id-${id}`)
        .attr('stroke', color)
        .attr('stroke-width', size)

      const moveEvent = event.type === 'mousedown'
        ? 'mousemove'
        : 'touchmove'

      svg.on(moveEvent, onMove)
    }

   const onMove = (event: any) => {
      event.preventDefault()
      points.push(d3.pointers(event)[0])
      tick()
    }

   const onEndDrawing = () => {
      svg.on('mousemove', null)
      svg.on('touchmove', null)

      if (!drawing) {
        return
      }

      drawing = false
      svg.select(`#id-${id}`).remove()
      id = uuid()
    }

   const tick = () => {
      requestAnimationFrame(() => {
        this.path.attr('d', points => {
          const path = d3.line().curve(d3.curveBasis)(points)
          const lines = this.node.attrs.lines.filter(item => item.id !== this.id)

          this.updateAttributes({
            lines: [
              ...lines,
              {
                id: id,
                color: color,
                size: size,
                path,
              },
            ],
          })

          return path
        })
      })
    }

const clear = () => {
      this.updateAttributes({
        lines: [],
      })
    }
onMounted(() => {
  svg = d3.select(this.$refs.canvas)

    svg
      .on('mousedown', this.onStartDrawing)
      .on('mouseup', this.onEndDrawing)
      .on('mouseleave', this.onEndDrawing)
      .on('touchstart', this.onStartDrawing)
      .on('touchend', this.onEndDrawing)
      .on('touchleave', this.onEndDrawing)
})
</script>
  
<style  lang="scss">
.draw {
  svg {
    background: #f1f3f5;
    cursor: crosshair;
  }

  path {
    fill: none;
    stroke-linecap: round;
    stroke-linejoin: round;
  }
}  
</style>