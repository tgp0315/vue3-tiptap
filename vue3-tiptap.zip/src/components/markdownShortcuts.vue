<template>
  <editor-content :editor="editor" />
</template>
  
<script setup lang='ts'>
import { Editor, EditorContent } from '@tiptap/vue-3';
import Highlight from '@tiptap/extension-highlight';
import Typography from '@tiptap/extension-typography';
import StarterKit from '@tiptap/starter-kit';
import { onMounted, ref, onBeforeUnmount } from 'vue';
const editor = ref()

onMounted(() => {
  editor.value = new Editor({
    extensions: [
      StarterKit,
      Highlight,
      Typography,
    ],
    content: `
      <p>
        Markdown shortcuts make it easy to format the text while typing.
      </p>
      <p>
        To test that, start a new line and type <code>#</code> followed by a space to get a heading. Try <code>#</code>, <code>##</code>, <code>###</code>, <code>####</code>, <code>#####</code>, <code>######</code> for different levels.
      </p>
      <p>
        Those conventions are called input rules in tiptap. Some of them are enabled by default. Try <code>></code> for blockquotes, <code>*</code>, <code>-</code> or <code>+</code> for bullet lists, or <code>\`foobar\`</code> to highlight code, <code>~~tildes~~</code> to strike text, or <code>==equal signs==</code> to highlight text.
      </p>
      <p>
        You can overwrite existing input rules or add your own to nodes, marks and extensions.
      </p>
      <p>
        For example, we added the <code>Typography</code> extension here. Try typing <code>(c)</code> to see how it’s converted to a proper © character. You can also try <code>-></code>, <code>>></code>, <code>1/2</code>, <code>!=</code>, or <code>--</code>.
      </p>
    `,
  })
})
onBeforeUnmount(() => {
  editor.value?.destroy()
})
</script>
  
<style>
  
</style>