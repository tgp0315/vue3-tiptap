import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/', 
    component: () => import('@/components/textEditor.vue')
  },
  {
    path: '/collaborativeEditing',
    component: () => import('@/components/collaborativeEditing.vue')
  },
  {
    path: '/markdownShortcuts',
    component: () => import('@/components/markdownShortcuts.vue')
  },
  {
    path: '/menus',
    component: () => import('@/components/Menus.vue')
  },
  {
    path: '/tables',
    component: () => import('@/components/Tables.vue')
  },
  {
    path: '/images',
    component: () => import('@/components/Images.vue')
  },
  {
    path: '/formatting',
    component: () => import('@/components/Formatting.vue')
  },
  {
    path: '/tasks',
    component: () => import('@/components/Tasks.vue')
  },
  {
    path: '/longTexts',
    component: () => import('@/components/LongTexts.vue')
  },
  {
    path: '/mentions',
    component: () => import('@/components/Mentions.vue')
  },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router