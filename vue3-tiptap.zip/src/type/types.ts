export type TNote = {
  id: string;
  content: string
}